#include "AsmTool.h"
#include "flib.h"
ElfPtr Elf32Ehdr(int entry)
{
    ElfPtr EhdrPtr;
    EhdrPtr.size = Elf32_EhdrSZ;
    EhdrPtr.ptr = (unsigned char *)malloc(Elf32_EhdrSZ);

    Elf32_Ehdr Ehdr;
    Ehdr.ident.magic1 = 127;
	Ehdr.ident.magic2 = 'E';
	Ehdr.ident.magic3 = 'L';
	Ehdr.ident.magic4 = 'F';
    Ehdr.ident.clas = EHDR_CLASS_32;
	Ehdr.ident.data = EHDR_DATA_2CLE;
	Ehdr.ident.version = EHDR_VERSION_CURRENT;
    Ehdr.ident.osabi = EHDR_OSABI_SYSTEM_V;
    Ehdr.ident.abi_version = EHDR_VERSION_NONE;
    f_memset(Ehdr.ident.none,0,7);
    Ehdr.type = EHDR_TYPE_EXEC;
    Ehdr.machine = EHDR_MACHINE_I386;
    Ehdr.version = EHDR_VERSION_CURRENT;
    Ehdr.entry = entry;  // .text 的地址是entry入口
    Ehdr.phoff = Elf32_EhdrSZ + 0;
    Ehdr.shoff = 0;
    Ehdr.flags = 0x0;
    Ehdr.ehsize = Elf32_EhdrSZ;
    Ehdr.phentsize = Elf32_PhdrSZ;
    Ehdr.phnum = 3;
    Ehdr.shentsize = 0;
    Ehdr.shnum = 0;
    Ehdr.shstrndx = 0;
    f_memcat(EhdrPtr.ptr,1,&Ehdr,Elf32_EhdrSZ);
    return EhdrPtr;
}
ElfPtr Elf32Phdr(int Interp_Offset,int Load_Filesz,int Dyn_Offset)
{
    ElfPtr Phdr;
    Phdr.size = Elf32_PhdrSZ * 3;
    Phdr.ptr = (unsigned char *)malloc(Elf32_PhdrSZ * 3);

    Elf32_Phdr Phdr_Interp;//链接器
    Elf32_Phdr Phdr_Load;//读执行的Load段
    Elf32_Phdr Phdr_Dyn;//动态段
    //链接器的信息
    Phdr_Interp.type = PHDR_TYPE_INTERP;
    Phdr_Interp.offset = Interp_Offset;//我这里interp是在Dyn后边的
    Phdr_Interp.vaddr = Elf32_BASE + Phdr_Interp.offset;//等于基址加偏移量
    Phdr_Interp.paddr = Elf32_BASE + Phdr_Interp.offset;//等于基址加偏移量
    Phdr_Interp.filesz = strlen("/lib/ld-linux.so.2") + 1;//strlen算长度的时候没加上\0
    Phdr_Interp.memsz = strlen("/lib/ld-linux.so.2") + 1;
    Phdr_Interp.flags =PHDR_FLAGS_READ;
    Phdr_Interp.align = 0x1;//1字节对齐
    f_memcat(Phdr.ptr,1,&Phdr_Interp,Elf32_PhdrSZ);
    //读,写,执行Load段信息
    Phdr_Load.type = PHDR_TYPE_LOAD;
    Phdr_Load.offset = 0;
    Phdr_Load.vaddr = Elf32_BASE;//等于基址
    Phdr_Load.paddr = Elf32_BASE;//等于基址
    Phdr_Load.filesz = Load_Filesz;
    Phdr_Load.memsz = Phdr_Load.filesz;
    Phdr_Load.flags = PHDR_FLAGS_READ + PHDR_FLAGS_EXEC + PHDR_FLAGS_WRITE;
    Phdr_Load.align = 0x1000;//4KB对齐
    f_memcat(Phdr.ptr,Elf32_PhdrSZ+1,&Phdr_Load,Elf32_PhdrSZ);
    //Dyn段信息
    Phdr_Dyn.type = PHDR_TYPE_DYNAMIC;
    Phdr_Dyn.offset = Dyn_Offset;
    Phdr_Dyn.vaddr = Elf32_BASE + Phdr_Dyn.offset;//等于基址加偏移量
    Phdr_Dyn.paddr = Elf32_BASE + Phdr_Dyn.offset;//等于基址加偏移量
    Phdr_Dyn.filesz = Elf32_DynSZ * 9;//我这动态段有11个
    Phdr_Dyn.memsz = Elf32_DynSZ * 9;
    Phdr_Dyn.flags = PHDR_FLAGS_READ + PHDR_FLAGS_WRITE;
    Phdr_Dyn.align = 0x4;//4字节对齐
    f_memcat(Phdr.ptr,Elf32_PhdrSZ*2+1,&Phdr_Dyn,Elf32_PhdrSZ);

    return Phdr;
}
ElfPtr Elf32Dyn(int Rel_Ptr,int Relsz_Val,int Sym_Ptr,int Str_Ptr,int Strsz_Val)
{
    ElfPtr Dyn;
    Dyn.size = Elf32_DynSZ * 9;
    Dyn.ptr = (unsigned char *)malloc(Elf32_DynSZ * 9);

    Elf32_Dyn Dyn_Need_Lib;//必需库
    Elf32_Dyn Dyn_Rel;
    Elf32_Dyn Dyn_Relent;
    Elf32_Dyn Dyn_Relsz;
    Elf32_Dyn Dyn_Sym;
    Elf32_Dyn Dyn_Syment;
    Elf32_Dyn Dyn_Str;
    Elf32_Dyn Dyn_Strsz;
    Elf32_Dyn Dyn_Null;
    //必需共享库
    Dyn_Need_Lib.tag = DYN_TAG_NEEDED;
    Dyn_Need_Lib.d_un.val = 1;
    f_memcat(Dyn.ptr,1,&Dyn_Need_Lib,Elf32_DynSZ);
    //重定位表
    Dyn_Rel.tag = DYN_TAG_REL;
    Dyn_Rel.d_un.ptr = Rel_Ptr;
    f_memcat(Dyn.ptr,Elf32_DynSZ+1,&Dyn_Rel,Elf32_DynSZ);
    //重定位表的每个项的大小
    Dyn_Relent.tag = DYN_TAG_RELENT;
    Dyn_Relent.d_un.val = Elf32_RelSZ;
    f_memcat(Dyn.ptr,Elf32_DynSZ*2+1,&Dyn_Relent,Elf32_DynSZ);
    //整张重定位表的大小
    Dyn_Relsz.tag = DYN_TAG_RELSZ;
    Dyn_Relsz.d_un.val = Relsz_Val;
    f_memcat(Dyn.ptr,Elf32_DynSZ*3+1,&Dyn_Relsz,Elf32_DynSZ);
    //符号表
    Dyn_Sym.tag = DYN_TAG_SYMTAB;
    Dyn_Sym.d_un.ptr = Sym_Ptr;
    f_memcat(Dyn.ptr,Elf32_DynSZ*4+1,&Dyn_Sym,Elf32_DynSZ);
    //符号表的每个项的大小
    Dyn_Syment.tag = DYN_TAG_SYMENT;
    Dyn_Syment.d_un.val = Elf32_SymSZ;
    f_memcat(Dyn.ptr,Elf32_DynSZ*5+1,&Dyn_Syment,Elf32_DynSZ);
    //函数名字串表
    Dyn_Str.tag = DYN_TAG_STRTAB;
    Dyn_Str.d_un.ptr = Str_Ptr;
    f_memcat(Dyn.ptr,Elf32_DynSZ*6+1,&Dyn_Str,Elf32_DynSZ);
    //整张函数名字串表的大小
    Dyn_Strsz.tag = DYN_TAG_STRSZ;
    Dyn_Strsz.d_un.val = Strsz_Val;
    f_memcat(Dyn.ptr,Elf32_DynSZ*7+1,&Dyn_Strsz,Elf32_DynSZ);
    //空表,一般都在最后加一个空表
    Dyn_Null.tag = DYN_TAG_NULL;
    Dyn_Null.d_un.val = 0;
    f_memcat(Dyn.ptr,Elf32_DynSZ*8+1,&Dyn_Null,Elf32_DynSZ);

    return Dyn;
}
ElfPtr Elf32Interp()
{
    ElfPtr Interp;
    Interp.size = f_strlen("/lib/ld-linux.so.2") + 1;
    Interp.ptr = (unsigned char *)malloc(Interp.size);

    f_memcat(Interp.ptr,1,"/lib/ld-linux.so.2",Interp.size);

    return Interp;
}
ElfPtr Elf32Data(AsmDataStr *DataStr)
{    
    ElfPtr Data;
    if(DataStr->next == NULL)
    {
        Data.ptr = NULL;
        Data.size = 0;
        return Data;
    }
    AsmDataStr *__DataStr = DataStr->next;
    int StrSZ = 0;
    int __Offset = 0;
    while(1)
    {printf("data is true......%s  %s\n",__DataStr->name,__DataStr->str);
        __Offset += f_strlen(__DataStr->str) + 1;
        if(__DataStr->next == NULL)
            break;
        __DataStr = __DataStr->next;
    }
    Data.size = __Offset;
    Data.ptr = (unsigned char *)malloc(Data.size);
    __DataStr = DataStr->next;
    __Offset = 1;
    while(1)
    {
        StrSZ = f_strlen(__DataStr->str) + 1;
        f_memcat(Data.ptr,__Offset,__DataStr->str,StrSZ);
        __Offset += StrSZ;
        if(__DataStr->next == NULL)
            break;
        __DataStr = __DataStr->next;
    }
    return Data;
}
ElfPtr Elf32Text(AsmOpc *Opc,AsmDataStr *DataStr,int Data_Offset,
                 int Text_Offset,ElfRelSym *RelSym,int *RelSymIndex)
{
    ElfPtr Text;
    if(Opc->next == NULL)
    {
        Text.ptr = NULL;
        Text.size = 0;
        return Text;
    }

    int __Offset = 0;
    int Call_Main_Offset = 0;
    AsmOpc *__Opc = Opc->next;
    AsmDataStr *__DataStr = DataStr->next;
    ElfRelSym *__RelSym = RelSym;

    while(1)
    {
        if(f_strcmp(__Opc->belfunc,"main") == f_equal)
            break;
        Call_Main_Offset += __Opc->size;
        __Opc = __Opc->next;
    }
    Call_Main_Offset += 9;

    unsigned char Start_Func1[4] = {0x58,0x54,0x50,0xe8};
	unsigned int Start_Func2 = Call_Main_Offset;
    unsigned char Start_Func3[9] = {0x89,0xc3,0xb8,0x01,0x0,0x0,0x0,0xcd,0x80};
    __Offset = 17;//_start 17 bytes
    __Opc = Opc->next;
    while(1)
    {
        __Offset += __Opc->size;
        if(__Opc->next == NULL)
            break;
        __Opc = __Opc->next;
    }
    printf("__offset:%d\n",__Offset);

    Text.size = __Offset;
    Text.ptr = (unsigned char *)malloc(Text.size);
    f_memcat(Text.ptr,1,Start_Func1,4);
    f_memcat(Text.ptr,4+1,&Start_Func2,4);
    f_memcat(Text.ptr,4+4+1,Start_Func3,9);
    __Offset = 17;

    int __OpcRnum = 0;
    int __JmpRnum = 0;
    int __record = 0;
    int __address = 0;
    int __islocal = 0;

    AsmOpc *__OpcToks;

    __Opc = Opc->next;
    AsmOpc *__belfunc = __Opc;

    while(1)
    {
        if(f_strcmp(__belfunc->belfunc,__Opc->belfunc) != f_equal)
        {
            __belfunc = __Opc;
            __JmpRnum = 1;
        }
        else
            __JmpRnum++;

        if(f_strcmp(__Opc->name,"call") == f_equal)
        {
            __islocal = 0;
            __address = 0;
            __record = 0;
            __OpcToks = Opc->next;

            while(1)
            {
                if(f_strcmp(__OpcToks->belfunc,__Opc->note) == f_equal)
                {
                    __islocal = 1;
                    break;
                }
                __record++;

                if(__OpcToks->next == NULL)
                    break;
                __OpcToks = __OpcToks->next;
            }
            if(__islocal == 1)
            {
                if(__record < __OpcRnum)
                {
                    __record = __OpcRnum - __record + 1;
                    while(__record--){
                        __address += __OpcToks->size;
                        __OpcToks = __OpcToks->next;
                    }
                    __address = 0 - __address;
                }
                else
                {
                    __record = __record - __OpcRnum - 1;
                    __OpcToks = __Opc->next;
                    while(__record--){
                        __address += __OpcToks->size;
                        __OpcToks = __OpcToks->next;
                    }
                }
            }
            else
            {
                ElfRelSym *NewRelSym = (ElfRelSym *)malloc(sizeof(ElfRelSym));
                NewRelSym->name = __Opc->note;
                NewRelSym->addr = Elf32_BASE + Text_Offset +__Offset + 1;
                NewRelSym->next = NULL;
                __RelSym->next = NewRelSym;
                __RelSym = NewRelSym;
                (*RelSymIndex)++;
                __address = -4;
            }
            f_memcat(Text.ptr,__Offset + 1,__Opc->opc,1);
            f_memcat(Text.ptr,__Offset + 2,&__address,4);
        }
        else if(f_strcmp(__Opc->name,"movl") == f_equal && __Opc->note != NULL)
        {
            __DataStr = DataStr->next;
            __address = 0;
            while(1){
                if(f_strcmp(__DataStr->name,__Opc->note) == f_equal)
                    break;printf("\ntext movl str to arg...\n");
                __address += f_strlen(__DataStr->str) + 1;

                if(__DataStr->next == NULL)
                    break;
                __DataStr = __DataStr->next;
            }
            __address = Elf32_BASE + Data_Offset + __address;printf("movl imm off(sep):%d...\n",__address);
            f_memcat(Text.ptr,__Offset + 1,__Opc->opc,f_strlen(__Opc->opc));
            f_memcat(Text.ptr,__Offset + f_strlen(__Opc->opc) + 1,&__address,4);
        }
        else if(f_strfch(__Opc->name,'j') == f_yes)
        {
            __record = 0;
            __address = 0;
            __OpcToks = __belfunc;

            while(1)
            {
                if(f_strcmp(__OpcToks->beljump,__Opc->note) == f_equal)
                    break;
                __record++;

                if(f_strcmp(__OpcToks->belfunc, __belfunc->belfunc) != f_equal)
                    break;
                __OpcToks = __OpcToks->next;
            }
            if(__record < __JmpRnum)
            {
                __record = (__JmpRnum-1) - __record + 1 ;
                while(__record--){
                    __address += __OpcToks->size;
                    __OpcToks = __OpcToks->next;
                }
                __address = 0 - __address;
            }
            else
            {printf("record:%d,jmpRnum:%d\n",__record,__JmpRnum);
                __record = __record - (__JmpRnum-1) - 1;printf("record:%d\n",__record);
                __OpcToks = __Opc->next;printf("jump source: %s\n",__Opc->name);
                while(__record--){printf("jump index: %s\n",__OpcToks->name);
                    __address += __OpcToks->size;
                    __OpcToks = __OpcToks->next;
                }
            }
            f_memcat(Text.ptr,__Offset + 1,__Opc->opc,f_strlen(__Opc->opc));
            f_memcat(Text.ptr,__Offset + f_strlen(__Opc->opc) + 1,&__address,1);
        }
        else{
            f_memcat(Text.ptr,__Offset + 1,__Opc->opc,__Opc->size);
        }printf("opc beljump is :%s \n",__Opc->beljump);

        __Offset += __Opc->size;
         __OpcRnum++;

        if(__Opc->next == NULL)
            break;
        __Opc = __Opc->next;
    }

    return Text;
}
ElfPtr Elf32Rel(ElfRelSym *RelSym,int RelSymIndex)
{
    ElfPtr Rel;
    if(RelSym->next == NULL)
    {
        Rel.ptr = NULL;
        Rel.size = 0;
        return Rel;
    }printf("RelSymIndex is : %d ...",RelSymIndex);
    ElfRelSym *__RelSym = RelSym->next;

    Elf32_Rel *RelTab = (Elf32_Rel *)malloc(Elf32_RelSZ * RelSymIndex);
    int i = 0;
    while(1)
    {
        RelTab[i].info = ELF32_REL_INFO(i + 1, REL_386_PC32);
        RelTab[i].offset = __RelSym->addr;
        i++;
        if(__RelSym->next == NULL)
            break;
        __RelSym = __RelSym->next;
    }
printf("rel func active \n");
    Rel.size = Elf32_RelSZ * RelSymIndex;
    Rel.ptr = (unsigned char *)RelTab;
    return Rel;
}

ElfPtr Elf32Sym(ElfRelSym *RelSym,int RelSymIndex,int StrTabFuncBeginIndex)
{
    ElfPtr Sym;
    Elf32_Sym *SymTab = (Elf32_Sym *)malloc(Elf32_SymSZ * RelSymIndex + 1);
	//符号表的第一个一般都是个空表
    SymTab[0].name = SYM_NAME_UNDEF;
    SymTab[0].value = 0;
    SymTab[0].size = 0;//不确定啊
    SymTab[0].info = 0;
    SymTab[0].other = 0;
    SymTab[0].shndx = 0;
    if(RelSym->next == NULL)
    {
        Sym.ptr = (unsigned char *)SymTab;
        Sym.size = Elf32_SymSZ;
        return Sym;
    }
    ElfRelSym *__RelSym = RelSym->next;
    int i = 1;
	int StrSymOffset = 0;
    while(1)
    {//这个是外部函数的
        SymTab[i].name = StrTabFuncBeginIndex + StrSymOffset;
        SymTab[i].value = 0;//虚拟地址
        SymTab[i].size = 0;
        SymTab[i].info = ELF32_SYM_INFO(SYM_INFO_BIND_GLOBAL,SYM_INFO_TYPE_FUNC);
        SymTab[i].other = SYM_OTHER_DEFAULT;
        SymTab[i].shndx = 0;//.text的在节头表中的索引号
        StrSymOffset += f_strlen(__RelSym->name) + 1;printf("sym :%s \n",__RelSym->name);
        i++;
        if(__RelSym->next == NULL)
            break;
        __RelSym = __RelSym->next;
    }
    Sym.ptr = (unsigned char *)SymTab;
    Sym.size = Elf32_SymSZ * (RelSymIndex + 1);
    return Sym;
}
ElfPtr Elf32Str(ElfRelSym *RelSym,int *StrTabFuncBeginIndex)//str should call before sym
{
    ElfPtr Str;
    char null = '\0';
    char *libc = "libc.so.6";
    int sysSpace = 1 + f_strlen(libc) + 1 ;
    *StrTabFuncBeginIndex = sysSpace;
    if(RelSym->next == NULL)
    {
        Str.size = sysSpace;printf("str null cao\n");
        Str.ptr = (unsigned char *)malloc(Str.size);
        f_memcat(Str.ptr,1,&null,1);
        f_memcat(Str.ptr,2,libc,f_strlen(libc) + 1);
        return Str;
    }
    ElfRelSym *__RelSym = RelSym->next;
    int __Offset = 0;
    while(1)
    {
        __Offset += f_strlen(__RelSym->name) + 1;
        if(__RelSym->next == NULL)
            break;
        __RelSym = __RelSym->next;
    }

    __RelSym = RelSym->next;
    Str.size = __Offset + sysSpace;
    Str.ptr = (unsigned char *)malloc(Str.size);
    f_memcat(Str.ptr,1,&null,1);
    f_memcat(Str.ptr,2,libc,f_strlen(libc) + 1);
    __Offset = sysSpace + 1;
    int len = 0;
    while(1)
    {
        len = f_strlen(__RelSym->name)+1;
        f_memcat(Str.ptr,__Offset,__RelSym->name,len);printf("str :%s \n",__RelSym->name);
        __Offset += len;
        if(__RelSym->next == NULL)
            break;
        __RelSym = __RelSym->next;
    }
	return Str;
}
void Elf32_Handling(AsmOpc *Opc,AsmDataStr *DataStr,FILE *Elf32ExecFile)
{

    ElfRelSym RelSym;
    RelSym.next = NULL;
    int RelSymIndex = 0;
    int StrTabFuncBeginIndex;

    int Phdr_Offset = Elf32_EhdrSZ;
    int Dyn_Offset = Phdr_Offset + Elf32_PhdrSZ * 3;
    int Interp_Offset = Dyn_Offset + Elf32_DynSZ * 9;
    //build
    ElfPtr Elf32Sec_Interp = Elf32Interp();
    int Data_Offset = Elf32Sec_Interp.size + Interp_Offset;
    ElfPtr  Elf32Sec_Data = Elf32Data(DataStr);
    int Text_Offset = Elf32Sec_Data.size + Data_Offset;
    ElfPtr Elf32Sec_Text = Elf32Text(Opc,DataStr,Data_Offset,Text_Offset,
                                     &RelSym,&RelSymIndex);printf("Elf32_Handling ....\n");
    int Rel_Offset = Elf32Sec_Text.size + Text_Offset;
    ElfPtr Elf32Sec_Rel = Elf32Rel(&RelSym,RelSymIndex);
    int Sym_Offset = Elf32Sec_Rel.size + Rel_Offset;
    ElfPtr Elf32Sec_Str = Elf32Str(&RelSym,&StrTabFuncBeginIndex);
    ElfPtr Elf32Sec_Sym = Elf32Sym(&RelSym,RelSymIndex,StrTabFuncBeginIndex);
    int Str_Offset = Elf32Sec_Sym.size + Sym_Offset;
    int Total_Offset = Elf32Sec_Str.size + Str_Offset;

    ElfPtr Elf32Sec_Ehdr = Elf32Ehdr(Text_Offset + Elf32_BASE);
    ElfPtr Elf32Sec_Phdr = Elf32Phdr(Interp_Offset,Total_Offset,Dyn_Offset);
    ElfPtr Elf32Sec_Dyn = Elf32Dyn(Elf32_BASE+Rel_Offset,Sym_Offset-Rel_Offset,
                                   Elf32_BASE+Sym_Offset,Elf32_BASE+Str_Offset,
                                   Total_Offset-Str_Offset);

    unsigned char *Elf32_Exec = (unsigned char *)malloc(Total_Offset);
    f_memcat(Elf32_Exec,1,Elf32Sec_Ehdr.ptr,Elf32Sec_Ehdr.size);
    f_memcat(Elf32_Exec,Phdr_Offset+1,Elf32Sec_Phdr.ptr,Elf32Sec_Phdr.size);
    f_memcat(Elf32_Exec,Dyn_Offset+1,Elf32Sec_Dyn.ptr,Elf32Sec_Dyn.size);
    f_memcat(Elf32_Exec,Interp_Offset+1,Elf32Sec_Interp.ptr,Elf32Sec_Interp.size);
    f_memcat(Elf32_Exec,Data_Offset+1,Elf32Sec_Data.ptr,Elf32Sec_Data.size);
    f_memcat(Elf32_Exec,Text_Offset+1,Elf32Sec_Text.ptr,Elf32Sec_Text.size);
    f_memcat(Elf32_Exec,Rel_Offset+1,Elf32Sec_Rel.ptr,Elf32Sec_Rel.size);
    f_memcat(Elf32_Exec,Sym_Offset+1,Elf32Sec_Sym.ptr,Elf32Sec_Sym.size);
    f_memcat(Elf32_Exec,Str_Offset+1,Elf32Sec_Str.ptr,Elf32Sec_Str.size);

    fwrite(Elf32_Exec,Total_Offset,1,Elf32ExecFile);
    fclose(Elf32ExecFile);
    free(Elf32_Exec);
}
