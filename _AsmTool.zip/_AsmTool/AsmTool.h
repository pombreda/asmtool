#ifndef AsmTool_H
#define AsmTool_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>

#define Elf32_BASE 0x8048000
#define Malloc(type,num) (type *)malloc(num * sizeof(type))
//Asm32.c

typedef struct _DataStr{
    char *name;
    char *str;
    struct _DataStr *next;
}AsmDataStr;

typedef struct _Opc{
    char *name;
    unsigned char *opc;
    int size;
    char *belfunc;
    char *beljump;
    char *note;
    struct _Opc *next;
}AsmOpc;

//Elf32.c

typedef struct{
    unsigned char *ptr;
    int size;
}ElfPtr;

typedef struct _RelSym{
    char *name;
    int addr;
    struct _RelSym *next;
}ElfRelSym;

//AsmTool.c
void _AsmTool(FILE *AsmFilePtr,FILE *ElfFilePtr);
//void *AsmTool_Malloc();
void AsmTool_Free();
void *AsmTool_Iterator();

//Elf32.h
typedef struct
{
    struct{
        unsigned char magic1;
        unsigned char magic2;
        unsigned char magic3;
        unsigned char magic4;
        unsigned char clas;
        unsigned char data;
        unsigned char version;
        unsigned char osabi;
        unsigned char abi_version;
        unsigned char none[7];
    }ident;
    unsigned short int type;
    unsigned short int machine;
    unsigned int version;
    unsigned int entry;
    unsigned int phoff;
    unsigned int shoff;
    unsigned int flags;
    unsigned short int ehsize;
    unsigned short int phentsize;
    unsigned short int phnum;
    unsigned short int shentsize;
    unsigned short int shnum;
    unsigned short int shstrndx;
}Elf32_Ehdr; //elf32_header'size is 52 bytes
#define Elf32_EhdrSZ sizeof(Elf32_Ehdr)

#define EHDR_CLASS_NONE      0  //none type
#define EHDR_CLASS_32           1  //elf 32
#define EHDR_CLASS_64           2

#define EHDR_DATA_2CLE             1  //little endian
#define EHDR_DATA_2CBE             2  //big endian

#define EHDR_OSABI_SYSTEM_V      0
#define EHDR_OSABI_FREEBSD        9
#define EHDR_OSABI_ARM               97
#define EHDR_OSABI_STANDALONE    255   //standalone(embedded) app

#define EHDR_TYPE_NONE       0  //none
#define EHDR_TYPE_REL          1  //Relocatable file
#define EHDR_TYPE_EXEC        2  //Executable file
#define EHDR_TYPE_DYN          3  //Shared object file
#define EHDR_TYPE_CORE        4  //Core file
#define EHDR_TYPE_NUM         5  //Number of defined types
#define EHDR_TYPE_LOPROC     0xff00  //Processor-specific
#define EHDR_TYPE_HIPROC      0xffff  //Processor-specific

#define EHDR_MACHINE_I386              3  //intel 80386
#define EHDR_MACHINE_I486                6
#define EHDR_MACHINE_MIPS_R3K        8 //MIPS R3000
#define EHDR_MACHINE_MIPS_R4K        10  //MIPS R4000
#define EHDR_MACHINE_ARM                 40  //ARM
#define EHDR_MACHINE_MIPS_X            51

#define EHDR_VERSION_NONE        0  //none
#define EHDR_VERSION_CURRENT     1  //current

typedef struct
{
  unsigned int    type;                 /* Segment type */
  unsigned int    offset;               /* Segment file offset */
  unsigned int    vaddr;                /* Segment virtual address */
  unsigned int    paddr;                /* Segment physical address */
  unsigned int    filesz;               /* Segment size in file */
  unsigned int    memsz;                /* Segment size in memory */
  unsigned int    flags;                /* Segment flags */
  unsigned int    align;                /* Segment alignment */
} Elf32_Phdr;  //program header size is 32 bytes 
#define Elf32_PhdrSZ sizeof(Elf32_Phdr)

#define PHDR_TYPE_NULL       0
#define PHDR_TYPE_LOAD       1
#define PHDR_TYPE_DYNAMIC        2
#define PHDR_TYPE_INTERP         3
#define PHDR_TYPE_NOTE       4
#define PHDR_TYPE_SHLIB       5
#define PHDR_TYPE_PHDR        6  /* Entry for header table itself */
#define PHDR_TYPE_NUM         7
#define PHDR_TYPE_LOOS         0x60000000      /* Start of OS-specific */
#define PHDR_TYPE_HIOS         0x6fffffff      /* End of OS-specific */
#define PHDR_TYPE_LOPROC       0x70000000      /* Start of processor-specific */
#define PHDR_TYPE_HIPROC       0x7fffffff      /* End of processor-specific */

#define PHDR_FLAGS_EXEC      1  
#define PHDR_FLAGS_WRITE     2  
#define PHDR_FLAGS_READ      4  
#define PHDR_FLAGS_PROC      0xf0000000

//dynamic
typedef struct
{
    int tag; //dynamic entry type
    union{
        unsigned int val;
        unsigned int ptr;
    }d_un;
}Elf32_Dyn;  //Dyn size is 8 bytes
#define Elf32_DynSZ	sizeof(Elf32_Dyn)

#define DYN_TAG_NULL        0
#define DYN_TAG_NEEDED      1  /* Name of needed library */
#define DYN_TAG_PLTRELSZ        2  /* Size in bytes of PLT relocs */
#define DYN_TAG_PLTGOT      3  /* Processor defined value */
#define DYN_TAG_HASH        4  /* SYM hash table address */
#define DYN_TAG_STRTAB      5
#define DYN_TAG_SYMTAB      6
#define DYN_TAG_RELA        7    /* Address of Rela relocs */
#define DYN_TAG_RELASE      8   /* Total size of Rela relocs */
#define DYN_TAG_RELAENT     9  /* Size of one Rela reloc */
#define DYN_TAG_STRSZ       10
#define DYN_TAG_SYMENT      11
#define DYN_TAG_INIT_FUNC       12  /* init func address */
#define DYN_TAG_FINI_FUNC       13  /* termination func address */
#define DYN_TAG_SONAME      14  /* shared object name */
#define DYN_TAG_RPATH       15  /* library search path */
#define DYN_TAG_SYMIC        16  /* start SYM search here */
#define DYN_TAG_REL         17  /* address of Rel relocs */
#define DYN_TAG_RELSZ       18
#define DYN_TAG_RELENT      19  /* Size of one Rel reloc */
#define DYN_TAG_PLTREL      20  /* Type of reloc in PLT */
#define DYN_TAG_DEBUG       21
#define DYN_TAG_TEXTREL     22  /* Reloc might modify .text */
#define DYN_TAG_JMPREL      23  /* Address of PLT relocs */
#define DYN_TAG_BIND_NOW    24  /* Process relocations of object */
#define DYN_TAG_INIT_ARRAY      25  /* Array with addresses of init func */
#define DYN_TAG_FINI_ARRAY      26  /* Array with addresses of fini func */
#define DYN_TAG_INIT_ARRAYSZ    27  /* Size in bytes of INIT_ARRAY */
#define DYN_TAG_FINI_ARRAYSZ    28
#define DYN_TAG_NUM     29
#define DYN_TAG_LOOS         0x60000000      /* Start of OS-specific */
#define DYN_TAG_HIOS         0x6fffffff      /* End of OS-specific */
#define DYN_TAG_LOPROC       0x70000000      /* Start of processor-specific */
#define DYN_TAG_HIPROC       0x7fffffff      /* End of processor-specific */
#define DYN_TAG_PROCNUM      0x32     /* Most used by any processor */

#define DYN_TAG_VALRNGLO     0x6ffffd00
#define DYN_TAG_POSFLAG1    0x6ffffdfd      /* Flags for DT_* entries, effecting
                                           the following DT_* entry.  */
#define DYN_TAG_SYMINSZ      0x6ffffdfe      /* Size of syminfo table (in bytes) */
#define DYN_TAG_SYMINENT     0x6ffffdff      /* Entry size of syminfo */
#define DYN_TAG_VALRNGHI     0x6ffffdff

#define DYN_TAG_ADDRRNGLO    0x6ffffe00
#define DYN_TAG_SYMINFO      0x6ffffeff      /* syminfo table */
#define DYN_TAG_ADDRRNGHI    0x6ffffeff

#define DYN_TAG_VERSYM       0x6ffffff0

typedef struct
{
    unsigned int 	    name;
    unsigned int 	    value;
    unsigned int 	    size;
    unsigned char	    info;
    unsigned char 	    other;
    unsigned short int  shndx;
} Elf32_Sym;
#define Elf32_SymSZ	sizeof(Elf32_Sym)

#define SYM_NAME_UNDEF       0               /* Undefined section */
#define SYM_NAME_LORESERVE   0xff00          /* Start of reserved indices */
#define SYM_NAME_LOPROC      0xff00          /* Start of processor-specific */
#define SYM_NAME_HIPROC      0xff1f          /* End of processor-specific */
#define SYM_NAME_ABS         0xfff1          /* Associated SYM is absolute */
#define SYM_NAME_COMMON      0xfff2          /* Associated SYM is common */
#define SYM_NAME_HIRESERVE   0xffff          /* End of reserved indices */

/* Legal values for ST_BIND subfield of st_info (SYM binding).  */
#define SYM_INFO_BIND_LOCAL       0               /* Local SYM */
#define SYM_INFO_BIND_GLOBAL      1               /* Global SYM */
#define SYM_INFO_BIND_WEAK        2               /* Weak SYM */
#define SYM_INFO_BIND_NUM         3               /* Number of defined types.  */
#define SYM_INFO_BIND_LOOS        10              /* Start of OS-specific */
#define SYM_INFO_BIND_HIOS        12              /* End of OS-specific */
#define SYM_INFO_BIND_LOPROC      13              /* Start of processor-specific */
#define SYM_INFO_BIND_HIPROC      15              /* End of processor-specific */
//legal vlaues for SYM_info(SYM type)
#define SYM_INFO_TYPE_NOTYPE      0
#define SYM_INFO_TYPE_OBJECT      1
#define SYM_INFO_TYPE_FUNC         2
#define SYM_INFO_TYPE_SECTION          3
#define SYM_INFO_TYPE_FILE        4
#define SYM_INFO_TYPE_NUM     5
#define SYM_INFO_TYPE_LOOS        11              /* Start of OS-specific */
#define SYM_INFO_TYPE_HIOS        12              /* End of OS-specific */
#define SYM_INFO_TYPE_LOPROC      13              /* Start of processor-specific */
#define SYM_INFO_TYPE_HIPROC      15              /* End of processor-specific */
/* How to extract and insert information held in the st_info field.  */
#define ELF32_SYM_INFO_BIND(val)              (((unsigned char) (val)) >> 4)
#define ELF32_SYM_INFO_TYPE(val)              ((val) & 0xf)
#define ELF32_SYM_INFO(bind, type)       (((bind) << 4) + ((type) & 0xf))

#define SYM_OTHER_DEFAULT        0
#define SYM_OTHER_INTERNAL       1
#define SYM_OTHER_HIDDEN         2
#define SYM_OTHER_PROTECTED    3
#define SYM_OTHER_EXPORTED      4
#define SYM_OTHER_SINGLETON     5
#define SYM_OTHER_ELIMINATE      6

#define ELF32_SYM_OTHER_VISIBILITY(VAR)        ((VAR) & 0X03)
typedef struct
{
  unsigned int   offset;               /* Address */
  unsigned int   info;                 /* Relocation type and SYM index */
} Elf32_Rel;
#define Elf32_RelSZ	sizeof(Elf32_Rel)
/* How to extract and insert information held in the Rel_info field.  */
#define ELF32_REL_SYM(val)                ((val) >> 8)
#define ELF32_REL_TYPE(val)               ((val) & 0xff)
#define ELF32_REL_INFO(sym, type)         (((sym) << 8) + ((type) & 0xff))
//这是上边的REL_TYPE的值
#define REL_386_NONE 0 
#define REL_386_32 1 
#define REL_386_PC32 2 
#define REL_386_GOT32 3 
#define REL_386_PLT32 4 
#define REL_386_COPY 5 
#define REL_386_GLOB_DAT 6 
#define REL_386_JMP_SLOT 7
#define REL_386_RELATIVE 8
#define REL_386_GOTOFF 9
#define REL_386_GOTPC 10
#define REL_386_32PLT 11
#define REL_386_16 20
#define REL_386_PC16 21
#define REL_386_8 22
#define REL_386_PC8 23
#define REL_386_SIZE32 38

//散列表
typedef struct
{
    unsigned int bucketnum;  //桶的个数
    unsigned int chainnum;  //链的个数的等于symtab的个数
}Elf32_Hash;
#define Elf32_HashSZ    sizeof(Elf32_Hash)

#endif
