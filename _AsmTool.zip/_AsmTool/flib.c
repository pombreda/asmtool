#include <stdlib.h>
#include "flib.h"
/*
strlen测的长度不包含\0
*/
int f_strlen(char *str)
{
    char *__str = str;
    int i = 0;

    while(*__str++)
        i++;
    return i;
}
/*
比较表b1和b2，如果b1 = b2返回0
*/
int f_memcmp(void *mc_b1,void *mc_b2,int mc_n)
{
    char *__mc_b1 = (char *)mc_b1;
    char *__mc_b2 = (char *)mc_b2;
    int ret = 0;
    while(mc_n-- > 0)
    {
        ret = *__mc_b1 - *__mc_b2;
        if(ret > 0)
            return ret = 1;
        if(ret < 0)
            return ret = -1;
        __mc_b1++;
        __mc_b2++;
    }
    return ret;
}
/*
将from里的前fr_n个字节连接到to的to_n的字节的位置，要求to要够大
to_n和fr_n都从1开始，和数组不同
*/
void *f_memcat(void *to,int to_n,void *from,int fr_n)
{
    unsigned char *__to = to;
    unsigned char *__from = from;
    int __to_n = to_n - 1;

    while (fr_n-- > 0)
    {
        __to[__to_n++] = *__from++;
    }
    return to;
}
/*
strncat将from的前frn字节连接到to后，并附上\0字串结束标志
*/
char *f_strncat(char *to,char *from,int fr_n)
{
    char *__to = to;
    char *__fr = from;

    while(*__to)
        __to++;
    while(fr_n-- > 0)
        *__to++ = *__fr++;
    *__to = '\0';
    return to;
}
/*
memset初始化指定单元的数据区
*/
void *f_memset(void *ms_m,int ch,int ms_n)
{
    char *__ms_m = (char *)ms_m;
    while(ms_n-- > 0)
    {
        *__ms_m++ = (char)ch;
    }
    return ms_m;
}
/*
    ch是否在str中
*/

int f_strfch(char *str,char ch)
{
    char __c;
    while(__c = *str++)
    {
        if(__c == ch)
            return 1;
    }
    return 0;
}
/*
    将ch连接到str后
*/
char *f_strlch(char *str,char ch)
{
    char *__str = str;

    while(*__str)
        __str++;
    *__str++ = ch;
    *__str = '\0';

    return str;
}
/*
strtok返回两个tok之间的字串
*/
char *f_strtok(char *str,char tok1,char tok2)
{
    char *__str = str;
    char *__ret = (char *)malloc(f_strlen(__str));
    char *ret = __ret;

    while(*__str++ != tok1);
    while(*__str != tok2)
    {
        *__ret++ = *__str++;
    }
    *__ret = '\0';
    return ret;
}
/*
在str1中寻找str2,找到返回 yes
*/
int f_strfstr(char *str1,char *str2)
{
    char *__str1 = str1;
    char *__str2 = str2;
    int __str2_n = f_strlen(__str2);
    int n = f_strlen(__str1) - __str2_n;

    while(n-- >= 0)
    {
        if(f_memcmp(__str1++,__str2,__str2_n) == 0)
            return 1;
    }
    return 0;
}

int f_atoi(char *str)
{
    char *__str = str;
    int ret = 0;

    if(*__str == '-' || *__str == '+')
        __str++;
    while(f_isdigit(*__str))
         ret = ret*10 + (*__str++ - '0');
    if(*str == '-')
        return 0 - ret;
    return ret;
}
