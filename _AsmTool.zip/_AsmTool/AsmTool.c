#include "flib.h"
#include "AsmTool.h"
#include "Asm32.c"
#include "Elf32.c"

void _AsmTool(FILE *Asm32SourceFile,FILE *Elf32ExecFile)
{
    AsmOpc Opc;
//    f_memset(&Opc,0,sizeof(AsmOpc));
    AsmDataStr DataStr;
//    f_memset(&DataStr,0,sizeof(AsmDataStr));

    Asm32_Handling(&Opc,&DataStr,Asm32SourceFile);
printf("skip Asm32_handling...\n");
    Elf32_Handling(&Opc,&DataStr,Elf32ExecFile);
}
/*
int main(int argc,char **argv)
{
    if(argc == 3){
        _AsmTool(fopen(argv[1],"r"),fopen(argv[2],"w"));
        chmod(argv[2],0755);
    }
    else
        printf("usage: ./AsmTool source.s elf.exe\n");
    return 0;
}
*/
int main()
{
    FILE *asmfile = fopen("9.s","r");
    FILE *elffile = fopen("elf.out","w");
    _AsmTool(asmfile,elffile);
    chmod("elf.out",0755);
    return 0;
}

