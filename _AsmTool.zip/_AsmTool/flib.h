#ifndef flib_h
#define flib_h

int f_strlen(char *str);

#define f_less -1
#define f_equal 0
#define f_greater 1
#define f_yes 1
#define f_no 0

int f_memcmp(void *mc_b1,void *mc_b2,int mc_n);

#define f_strcmp(str1,str2) f_memcmp(str1,str2,f_strlen(str1))

void *f_memcat(void *to,int to_n,void *from,int fr_n);

#define f_memcpy(to,from,n) f_memcat(to,1,from,n)

#define f_strcpy(to,from) f_memcat(to,1,from,f_strlen(from)+1)

#define f_strcat(to,from) f_memcat(to,f_strlen(to)+1,from,f_strlen(from)+1)

char *f_strncat(char *to,char *from,int fr_n);

void *f_memset(void *ms_m,int ch,int ms_n);

int f_strfch(char *str,char ch);

char *f_strlch(char *str,char ch);

char *f_strtok(char *str,char tok1,char tok2);

int f_strfstr(char *str1,char *str2);

#define f_isdigit(num) (num >= '0' && num <= '9')

int f_atoi(char *str);

#define f_isspace(ch) (ch == ' ' || ch == '\t')

#endif
