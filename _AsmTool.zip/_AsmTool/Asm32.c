#include "AsmTool.h"
#include "flib.h"

char *Asm_StrMal(void *str)
{
    int size = f_strlen(str) + 1;
    char *rec = (char *)malloc(size);
    return f_memcat(rec,1,str,size);
}
unsigned char *Asm_OpcMal(void *opc,int num,int immsz)
{
    int opcsz = f_strlen(opc);
    unsigned char *opcimm = malloc(opcsz + immsz + 1);
    f_memcat(f_memcat(opcimm,1,opc,opcsz),opcsz+1,&num,immsz);
    opcimm[opcsz + immsz] = '\0';
    return opcimm;
}

char *Asm_GetOpcS(char *LineStr)
{
    char *__LineStr = LineStr;
    char *ret = (char *)malloc(f_strlen(__LineStr) + 1);
    char *__ret = ret;

    while(f_isspace(*__LineStr))
        __LineStr++;
    while(!f_isspace(*__LineStr))
        __LineStr++;
    while(1){
        if(!f_isspace(*__LineStr))
            break;
        __LineStr++;
    }
    while(*__LineStr && !f_isspace(*__LineStr) && *__LineStr != ',')
    {
        *__ret++ = *__LineStr++;
    }
    *__ret = '\0';

    return ret;
}
char *Asm_GetOpcT(char *LineStr)
{
    char *__LineSrc = LineStr;
    char *ret = (char *)malloc(f_strlen(__LineSrc));
    char *__ret = ret;

    while(*__LineSrc++ != ',');
    while(*__LineSrc++)
    {
        if(!f_isspace(*__LineSrc))
            *__ret++ = *__LineSrc;
    }
    *__ret = '\0';

    return ret;
}
int Asm_GetOpcN(char *OpcST)
{
    char *__OpcST = OpcST;
    if(*__OpcST == '$')
        __OpcST++;

    return f_atoi(__OpcST);
}
char *Asm_GetOpcR(char *OpcST)
{
    char *__OpcST = OpcST;
    char *ret = (char *)malloc(f_strlen(__OpcST));
    char *__ret = ret;
    while(1)
    {
        if(*__OpcST == '(')
            break;
        if(*__OpcST == '%')
            break;
        __OpcST++;
    }
    while(*__OpcST)
    {
        *__ret++ = *__OpcST++;
    }
    *__ret = '\0';

    return ret;
}

void Asm_NoFound(char *str)
{
    printf("Asm No Opc:%s\n",str);
}
AsmOpc *Asm_Movl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{    
    unsigned char movl_eax_edx[] = {0x89,0xc2,0};
    unsigned char movl_edx_ecx[] = {0x89,0xd1,0};
    unsigned char movl_ecx_eax[] = {0x89,0xc8,0};
    unsigned char movl_esp_ebp[] = {0x89,0xe5,0};
    unsigned char movl_imm_eax[] = {0xb8,0};
    unsigned char movl_str_eax[] = {0xb8,0};
    unsigned char movl_eax_Pesp[] = {0x89,0x04,0x24,0};   
    unsigned char movl_str_Pesp[] = {0xc7,0x04,0x24,0};//str shi int    
    unsigned char movl_offPebp_eax[] = {0x8b,0x45,0};//off shi char
    unsigned char movl_offPebp_edx[] = {0x8b,0x55,0};//off shi char
    unsigned char movl_offPesp_eax[] = {0x8b,0x44,0x24,0};//off shi char
    unsigned char movl_offPesp_edx[] = {0x8b,0x54,0x24,0};
    unsigned char movl_eax_offPebp[] = {0x89,0x45,0};
    unsigned char movl_imm_offPebp[] = {0xc7,0x45,0};//off shi char,num shi int
    unsigned char movl_str_offPesp[] = {0xc7,0x44,0x24,0};//off shi char ,imm shi int
    unsigned char movl_eax_offPesp[] = {0x89,0x44,0x24,0};//off shi char
    unsigned char movl_ebx_offPesp[] = {0x89,0x5c,0x24,0};//off shi char
    unsigned char movl_edx_offPesp[] = {0x89,0x54,0x24,0};//off shi char


    int num = 0;
    int off = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("movl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->note = NULL;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%esp") == f_equal && f_strcmp(AsmOpcT,"%ebp") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movl_esp_ebp);
        OpcNode->size = 2;
    }
    else if(f_strcmp(AsmOpcS,"%eax") == f_equal && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movl_eax_edx);
        OpcNode->size = 2;
    }
    else if(f_strcmp(AsmOpcS,"%edx") == f_equal && f_strfstr(AsmOpcT,"(%esp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(movl_edx_offPesp,num,1);
        OpcNode->size = 4;
    }
    else if(f_strcmp(AsmOpcS,"%eax") == f_equal && f_strcmp(AsmOpcT,"(%esp)") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movl_eax_Pesp);
        OpcNode->size = 3;
    }
    else if(f_strcmp(AsmOpcS,"%eax") == f_equal && f_strfstr(AsmOpcT,"(%esp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(movl_eax_offPesp,num,1);
        OpcNode->size = 4;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->size = 5;
        if(f_strfch(AsmOpcS,'.') == f_yes){
            OpcNode->opc = Asm_StrMal(movl_str_eax);
            OpcNode->note = ++AsmOpcS;//$.LC1
        }
        else{
            num = Asm_GetOpcN(AsmOpcS);
            OpcNode->opc = Asm_OpcMal(movl_imm_eax,num,4);
        }
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"(%esp)") == f_equal)
    {
        OpcNode->size = 7;
        if(f_strfch(AsmOpcS,'.') == f_yes){
            OpcNode->opc = Asm_StrMal(movl_str_Pesp);
            OpcNode->note = ++AsmOpcS;//$.LC1
        }
        else{
            Asm_NoFound(LineStr);
        }
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strfstr(AsmOpcT,"(%esp)") == f_yes)
    {
        off = Asm_GetOpcN(AsmOpcT);
        if(f_strfch(AsmOpcS,'.') == f_yes){
            OpcNode->opc = Asm_OpcMal(movl_str_offPesp,off,1);
            OpcNode->note = ++AsmOpcS;//$.LC1
        }
        else{
            num = Asm_GetOpcN(AsmOpcS);
            OpcNode->opc = Asm_OpcMal(Asm_OpcMal(movl_str_offPesp,off,1),num,4);
        }
        OpcNode->size = 8;
    }
    else if(f_strfstr(AsmOpcS,"(%ebp)") == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(movl_offPebp_eax,num,1);
        OpcNode->size = 3;
        if(num == 0) printf("movl (%ebp),%eax hao xiang fa sheng gu zhang.\n");
    }
    else if(f_strcmp(AsmOpcS,"%eax") == f_equal && f_strfstr(AsmOpcT,"(%ebp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(movl_eax_offPebp,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strfstr(AsmOpcT,"(%ebp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcS);
        off = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(Asm_OpcMal(movl_imm_offPebp,off,1),num,4);
        OpcNode->size = 7;
    }
    else if(f_strfstr(AsmOpcS,"(%ebp)") == f_yes && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(movl_offPebp_edx,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfstr(AsmOpcS,"(%esp)") == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(movl_offPesp_eax,num,1);
        OpcNode->size = 4;
    }
    else if(f_strcmp(AsmOpcS,"%ebx") == f_equal && f_strfstr(AsmOpcT,"(%esp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(movl_ebx_offPesp,num,1);
        OpcNode->size = 4;
    }
    else if(f_strcmp(AsmOpcS,"%edx") == f_equal && f_strcmp(AsmOpcT,"%ecx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movl_edx_ecx);
        OpcNode->size = 2;
    }
    else if(f_strcmp(AsmOpcS,"%ecx") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movl_ecx_eax);
        OpcNode->size = 2;
    }
    else if(f_strfstr(AsmOpcS,"(%esp)") == f_yes && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(movl_offPesp_edx,num,1);
        OpcNode->size = 4;
    }
    else
       Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Movb(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char movb_imm_Peax[] = {0xc6,0x0,0};//num shi char
    unsigned char movb_dl_Peax[] = {0x88,0x10,0};
    unsigned char movb_imm_offPesp[] = {0xc6,0x44,0x24,0};//off shi char , imm shi char
//    unsigned char movb_cl_Pedx[] = ;

    int num = 0;
    int off = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("movb");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->note = NULL;
    OpcNode->next = NULL;

    if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"(%eax)") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(Asm_OpcMal(movb_imm_Peax,0,1),num,1);
        OpcNode->size = 3;
    }
    else if(f_strcmp(AsmOpcS,"%dl") == f_equal && f_strcmp(AsmOpcT,"(%eax)") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movb_dl_Peax);
        OpcNode->size = 2;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strfstr(AsmOpcT,"(%esp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcS);
        off = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(Asm_OpcMal(movb_imm_offPesp,off,1),num,1);
        OpcNode->size = 5;
    }
    else
       Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Movsbl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char movsbl_al_eax[] = {0x0f,0xbe,0xc0,0};
    unsigned char movsbl_dl_edx[] = {0x0f,0xbe,0xd2,0};
    unsigned char movsbl_al_edx[] = {0x0f,0xbe,0xd0,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("movb");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->note = NULL;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%al") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movsbl_al_eax);
        OpcNode->size = 3;
    }
    else if(f_strcmp(AsmOpcS,"%dl") == f_equal && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movsbl_dl_edx);
        OpcNode->size = 3;
    }
    else if(f_strcmp(AsmOpcS,"%al") == f_equal && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movsbl_al_edx);
        OpcNode->size = 3;
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Movzbl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char movzbl_al_eax[] = {0x0f,0xb6,0xc0,0};
    unsigned char movzbl_al_edx[] = {0x0f,0xb6,0xd0,0};
    unsigned char movzbl_dl_edx[] = {0x0f,0xb6,0xd2,0};
    unsigned char movzbl_Peax_eax[] = {0x0f,0xb6,0x0,0};
    unsigned char movzbl_Pedx_edx[] = {0x0f,0xb6,0x12,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("movb");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->note = NULL;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%al") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movzbl_al_eax);
        OpcNode->size = 3;
    }
    else if(f_strcmp(AsmOpcS,"%al") == f_equal && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movzbl_al_edx);
        OpcNode->size = 3;
    }
    else if(f_strcmp(AsmOpcS,"%dl") == f_equal && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movzbl_dl_edx);
        OpcNode->size = 3;
    }
    else if(f_strcmp(AsmOpcS,"(%eax)") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_OpcMal(movzbl_Peax_eax,0,1);
        OpcNode->size = 3;
    }
    else if(f_strcmp(AsmOpcS,"(%edx)") == f_equal && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(movzbl_Pedx_edx);
        OpcNode->size = 3;
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Addl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char addl_edx_eax[] = {0x21,0xd0,0};
    unsigned char addl_imm_offPebp[] = {0x83,0x45,0};//off shi char,imm shi char
    unsigned char addl_offPebp_eax[] = {0x03,0x45,0};
    unsigned char addl_imm_eax[] = {0x83,0xc0,0};
    unsigned char addl_imm_esp[] = {0x83,0xc4,0};

    int num = 0;
    int off = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("addl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%edx") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(addl_edx_eax);
        OpcNode->size = 2;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strfstr(AsmOpcT,"(%ebp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcS);
        off = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(Asm_OpcMal(addl_imm_offPebp,off,1),num,1);
        OpcNode->size = 4;
    }
    else if(f_strfstr(AsmOpcS,"(%ebp)") == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(addl_offPebp_eax,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(addl_imm_eax,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%esp") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(addl_imm_esp,num,1);
        OpcNode->size = 3;
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Call(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char call[] = {0xe8,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("call");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(call);
    OpcNode->size = 5;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Jmp(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char jmp[] = {0xeb,0};//jum .L0 ; .L0 shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("jmp");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(jmp);
    OpcNode->size = 2;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Cmpl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char cmpl_ebx_eax[] = {0x39,0xd8,0};
    unsigned char cmpl_imm_eax[] = {0x83,0xf8,0};
    unsigned char cmpl_imm_offPebp[] = {0x83,0x7d,0};//off shi char,imm shi char

    int num = 0;
    int off = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("cmpl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%ebx") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(cmpl_ebx_eax);
        OpcNode->size = 2;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(cmpl_imm_eax,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strfstr(AsmOpcT,"(%ebp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcS);
        off = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(Asm_OpcMal(cmpl_imm_offPebp,off,1),num,1);
        OpcNode->size = 4;
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Cmpb(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char cmpb_imm_al[] = {0x3c,0};//num shi char

    int num = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("cmpb");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%al") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(cmpb_imm_al,num,1);
        OpcNode->size = 2;
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Jne(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char jne[] = {0x75,0};//jne .L0 ; .L0 shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("jne");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(jne);
    OpcNode->size = 2;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Subl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char subl_imm_esp[] = {0x83,0xec,0};//num shi char
    unsigned char subl_imm_eax[] = {0x83,0xe8,0};
    unsigned char subl_imm_offPebp[] = {0x83,0x6d,0};//off shi char,imm shi char
    unsigned char subl_eax_ecx[] = {0x29,0xc1,0};
    unsigned char subl_offPebp_eax[] = {0x2b,0x45,0};

    int num = 0;
    int off = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("subl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%esp") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(subl_imm_esp,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(subl_imm_eax,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strfstr(AsmOpcT,"(%ebp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcS);
        off = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(Asm_OpcMal(subl_imm_offPebp,off,1),num,1);
        OpcNode->size = 4;
    }
    else if(f_strcmp(AsmOpcS,"%eax") == f_equal && f_strcmp(AsmOpcT,"%ecx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(subl_eax_ecx);
        OpcNode->size = 2;
    }
    else if(f_strfstr(AsmOpcS,"(%ebp)") == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(subl_offPebp_eax,num,1);
        OpcNode->size = 3;
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Ret(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char ret[] = {0xc3,0};

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("ret");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;
    OpcNode->opc = Asm_StrMal(ret);
    OpcNode->size = 1;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Neg(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char neg_eax[] = {0xf7,0xd8,0};
    unsigned char neg_edx[] = {0xf7,0xda,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("neg");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->size = 2;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(neg_eax);
    }
    else if(f_strcmp(AsmOpcS,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(neg_edx);
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Pushl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char pushl_ebp[] = {0x55,0};
    unsigned char pushl_ebx[] = {0x53,0};
    unsigned char pushl_ecx[] = {0x51,0};
    unsigned char pushl_esi[] = {0x56,0};
    unsigned char pushl_eax[] = {0x50,0};
    unsigned char pushl_esp[] = {0x54,0};
    unsigned char pushl_edx[] = {0x52,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("pushl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->size = 1;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%ebp") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(pushl_ebp);
    }
    else if(f_strcmp(AsmOpcS,"%ebx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(pushl_ebx);
    }
    else if(f_strcmp(AsmOpcS,"%ecx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(pushl_ecx);
    }
    else if(f_strcmp(AsmOpcS,"%esi") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(pushl_esi);
    }
    else if(f_strcmp(AsmOpcS,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(pushl_eax);
    }
    else if(f_strcmp(AsmOpcS,"%esp") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(pushl_esp);
    }
    else if(f_strcmp(AsmOpcS,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(pushl_edx);
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Popl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char popl_eax[] = {0x58,0};
    unsigned char popl_ebx[] = {0x5b,0};
    unsigned char popl_ebp[] = {0x5d,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("popl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->size = 1;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(popl_eax);
    }
    else if(f_strcmp(AsmOpcS,"%ebx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(popl_ebx);
    }
    else if(f_strcmp(AsmOpcS,"%ebp") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(popl_ebp);
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Je(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char je[] = {0x74,0};//jne .L0 ; .L0 shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("je");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(je);
    OpcNode->size = 2;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Orl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char orl_edx_eax[] = {0x09,0xd0,0};
    unsigned char orl_eax_edx[] = {0x09,0xc2,0};
    unsigned char orl_ecx_eax[] = {0x09,0xc8,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("orl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->size = 2;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%edx") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(orl_edx_eax);
    }
    else if(f_strcmp(AsmOpcS,"%eax") == f_equal && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(orl_eax_edx);
    }
    else if(f_strcmp(AsmOpcS,"%ecx") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(orl_ecx_eax);
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Testl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char testl_edx_edx[] = {0x85,0xd2,0};
    unsigned char testl_eax_eax[] = {0x85,0xc0,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("testl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->size = 2;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%edx") == f_equal && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(testl_edx_edx);
    }
    else if(f_strcmp(AsmOpcS,"%eax") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(testl_eax_eax);
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Testb(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char testb_al_al[] = {0x84,0xc0,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("testb");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->size = 2;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%al") == f_equal && f_strcmp(AsmOpcT,"%al") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(testb_al_al);
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Sete(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char sete_al[] = {0x0f,0x94,0xc0,0};
    unsigned char sete_dl[] = {0x0f,0x94,0xc2,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("sete");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->size = 3;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%al") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(sete_al);
    }
    else if(f_strcmp(AsmOpcS,"%dl") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(sete_dl);
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Setne(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char setne_al[] = {0x0f,0x95,0xc0,0};
    unsigned char setne_cl[] = {0x0f,0x95,0xc1,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("setne");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->size = 3;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%al") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(setne_al);
    }
    else if(f_strcmp(AsmOpcS,"%cl") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(setne_cl);
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Setg(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char setg_al[] = {0x0f,0x9f,0xc0,0};

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("setg");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->size = 3;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%al") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(setg_al);
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Jl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char jl[] = {0x7c,0};//jne .L0 ; .L0 shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("jl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(jl);
    OpcNode->size = 2;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Jle(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char jle[] = {0x7e,0};//jne .L0 ; .L0 shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("jle");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(jle);
    OpcNode->size = 2;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Jg(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char jg[] = {0x7f,0};//jne .L0 ; .L0 shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("jg");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(jg);
    OpcNode->size = 2;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Jns(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char jns[] = {0x79,0};//jne .L0 ; .L0 shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("jns");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(jns);
    OpcNode->size = 2;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Leave(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char leave[] = {0xc9,0};

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("leave");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;
    OpcNode->opc = Asm_StrMal(leave);
    OpcNode->size = 1;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Leal(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char leal_offPebp_edx[] = {0x8d,0x55,0};
    unsigned char leal_offPeax_edx[] = {0x8d,0x50,0};//off shi char
    unsigned char leal_offPesp_edx[] = {0x8d,0x54,0x24,0};
    unsigned char leal_offPeax_ebx[] = {0x8d,0x58,0};
    unsigned char leal_offPesp_eax[] = {0x8d,0x44,0x24,0};//off shi char
    unsigned char leal_Pedxeax_eax[] = {0x8d,0x4,0x2,0};
//    unsigned char leal_offPebp_eax[] ;
//    unsigned char leal_offPeaximm_edx[];

    int num = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("leal");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strfstr(AsmOpcS,"(%ebp)") == f_yes && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(leal_offPebp_edx,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfstr(AsmOpcS,"(%eax)") == f_yes && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(leal_offPeax_edx,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfstr(AsmOpcS,"(%esp)") == f_yes && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(leal_offPesp_edx,num,1);
        OpcNode->size = 4;
    }
    else if(f_strfstr(AsmOpcS,"(%eax)") == f_yes && f_strcmp(AsmOpcT,"%ebx") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(leal_offPeax_ebx,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfstr(AsmOpcS,"(%esp)") == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(leal_offPesp_eax,num,1);
        OpcNode->size = 4;
    }
    else if(f_strfstr(LineStr,"(%edx,%eax)") == f_yes && f_strfstr(AsmOpcT,",%eax") == f_yes)
    {
        //此函数可能包含bug
        OpcNode->opc = Asm_StrMal(leal_Pedxeax_eax);
        OpcNode->size = 3;
    }
    else
       Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Nop(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char nop[] = {0x90,0};

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));

    OpcNode->name = Asm_StrMal("nop");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;
    OpcNode->opc = Asm_StrMal(nop);
    OpcNode->size = 1;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Jge(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char jge[] = {0x7d,0};//jne .L0 ; .L0 shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("jge");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(jge);
    OpcNode->size = 2;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Sarl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char sarl_imm_eax[] = {0xc1,0xf8,0};
    unsigned char sarl_imm_edx[] = {0xc1,0xfa,0};
    unsigned char sarl_imm_offPebp[] = {0xc1,0x7d,0};//off he num shi char,qian xie off

    int num = 0;
    int off = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("sarl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(sarl_imm_eax,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(sarl_imm_edx,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strfstr(AsmOpcT,"(%ebp)") == f_yes)
    {
        num = Asm_GetOpcN(AsmOpcS);
        off = Asm_GetOpcN(AsmOpcT);
        OpcNode->opc = Asm_OpcMal(Asm_OpcMal(sarl_imm_offPebp,off,1),num,1);
        OpcNode->size = 4;
    }
    else
       Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Ja(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char ja[] = {0x77,0};//jne .L0 ; .L0 shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("ja");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->opc = Asm_StrMal(ja);
    OpcNode->size = 2;
    OpcNode->note = AsmOpcS;

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Sall(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char sall_imm_eax[] = {0xc1,0xe0,0};//num shi char
    unsigned char sall_imm_edx[] = {0xc1,0xe2,0};

    int num = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("sall");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(sall_imm_eax,num,1);
        OpcNode->size = 3;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%edx") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(sall_imm_edx,num,1);
        OpcNode->size = 3;
    }
    else
       Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Andl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char andl_imm_esp[] = {0x83,0xe4,0};
    unsigned char andl_edx_eax[] = {0x21,0xd0,0};
    unsigned char andl_imm_eax[] = {0x25,0};//num shi int
    unsigned char andl_ecx_eax[] = {0x21,0xc8,0};
    unsigned char andl_offPebp_eax[] = {0x23,0x45,0};

    int num = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("andl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%esp") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(andl_imm_esp,num,1);
        OpcNode->size = 3;
    }
    else if(f_strcmp(AsmOpcS,"%edx") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(andl_edx_eax);
        OpcNode->size = 2;
    }
    else if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(andl_imm_eax,num,4);
        OpcNode->size = 5;
    }
    else if(f_strcmp(AsmOpcS,"%ecx") == f_equal && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(andl_ecx_eax);
        OpcNode->size = 2;
    }
    else if(f_strfstr(AsmOpcS,"(%ebp)") == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(andl_offPebp_eax,num,1);
        OpcNode->size = 3;
    }
    else
       Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}

AsmOpc *Asm_Xorl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char xorl_imm_eax[] = {0x83,0xf0,0};//num shi char

    int num = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("xorl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(xorl_imm_eax,num,1);
        OpcNode->size = 3;
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Notl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char notl_eax[] = {0xf7,0xd0,0};//num shi char

    char *AsmOpcS = Asm_GetOpcS(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("notl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strcmp(AsmOpcS,"%eax") == f_equal)
    {
        OpcNode->opc = Asm_StrMal(notl_eax);
        OpcNode->size = 2;
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmOpc *Asm_Shrl(AsmOpc *OpcLink,char *belfunc,char *beljump,char *LineStr)
{
    unsigned char shrl_imm_eax[] = {0xc1,0xe8,0};//num shi char

    int num = 0;
    char *AsmOpcS = Asm_GetOpcS(LineStr);
    char *AsmOpcT = Asm_GetOpcT(LineStr);

    AsmOpc *OpcNode = (AsmOpc *)malloc(sizeof(AsmOpc));
    OpcNode->name = Asm_StrMal("shrl");
    OpcNode->belfunc = belfunc;
    OpcNode->beljump = beljump;
    OpcNode->next = NULL;

    if(f_strfch(AsmOpcS,'$') == f_yes && f_strcmp(AsmOpcT,"%eax") == f_equal)
    {
        num = Asm_GetOpcN(AsmOpcS);
        OpcNode->opc = Asm_OpcMal(shrl_imm_eax,num,1);
        OpcNode->size = 3;
    }
    else
        Asm_NoFound(LineStr);

    OpcLink->next = OpcNode;
    return OpcNode;
}
AsmDataStr *Asm_StrTok(AsmDataStr *DataStrLink,char *StrTok,char *string)
{
    char *str = f_strtok(string,'"','"');
    AsmDataStr *DataStrNode = (AsmDataStr *)malloc(sizeof(AsmDataStr));

    DataStrNode->name = StrTok;
    DataStrNode->str = str;
    DataStrNode->next = NULL;
    DataStrLink->next = DataStrNode;

    return DataStrNode;
}
void Asm32_Handling(AsmOpc *Opc,AsmDataStr *DataStr,FILE *Asm32SourceFile)
{
    int  Asm = 1;
    char *LineKey;
    char *__bel = "__bel";
    char *belfunc = __bel;
    char *beljump = __bel;
    char ch;

    char *LineStr;
    char *__LineStr;

    char ReaRec = 2;
    int PubSpa = 0;

    int linenumber = 1;

    //链表的第一个节点不用
    Opc->next = NULL;
    DataStr->next = NULL;
    AsmOpc *OpcNode = Opc;
    AsmDataStr *DataStrNode = DataStr;

    while(Asm)
    {
        PubSpa = 0;
        ReaRec = 2;
        LineStr = (char *)malloc(8);
        while(1)
        {
            if(feof(Asm32SourceFile))
            {
                Asm = 0;
                break;
            }
            if(PubSpa >= 7)
            {
                LineStr = (char *)realloc(LineStr,8 * ReaRec);
                ReaRec++;
                PubSpa = 0;
            }
            ch = fgetc(Asm32SourceFile);
            if(ch == '\n')
                break;
            f_strlch(LineStr,ch);
            PubSpa++;
        }

        __LineStr = LineStr;
        LineKey = (char *)malloc(f_strlen(__LineStr) + 1);

        while(1){
            if(f_isspace(*__LineStr))
                __LineStr++;
            else
                break;
        }
        while(1)
        {
            if(f_isspace(*__LineStr) || *__LineStr == '\0')
                break;
            else
                f_strlch(LineKey,*__LineStr++);
        }

        if(f_strfch(LineKey,'.') == f_yes &&f_strfch(LineKey,':') == f_yes)
        {
            PubSpa = f_strlen(LineKey);
            LineKey[PubSpa - 1] = '\0';
            beljump = LineKey;
        }
        else if(f_strfch(LineKey,':') == f_yes)
        {
            PubSpa = f_strlen(LineKey);
            LineKey[PubSpa - 1] = '\0';
            belfunc = LineKey;
        }
        if(f_strcmp(LineKey,".string") == f_equal){printf("\n\n%s\n\n",beljump);
            DataStrNode = Asm_StrTok(DataStrNode,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"movl") == f_equal){
            OpcNode = Asm_Movl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"movb") == f_equal){
            OpcNode = Asm_Movb(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"movsbl") == f_equal){
            OpcNode = Asm_Movsbl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"movzbl") == f_equal){
            OpcNode = Asm_Movzbl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"addl") == f_equal){
            OpcNode = Asm_Addl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"call") == f_equal){
            OpcNode = Asm_Call(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"jmp") == f_equal){
            OpcNode = Asm_Jmp(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"cmpb") == f_equal){
            OpcNode = Asm_Cmpb(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"cmpl") == f_equal){
            OpcNode = Asm_Cmpl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"subl") == f_equal){
            OpcNode = Asm_Subl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"ret") == f_equal){
            OpcNode = Asm_Ret(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"neg") == f_equal){
            OpcNode = Asm_Neg(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"pushl") == f_equal){
            OpcNode = Asm_Pushl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"popl") == f_equal){
            OpcNode = Asm_Popl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"orl") == f_equal){
            OpcNode = Asm_Orl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"testl") == f_equal){
            OpcNode = Asm_Testl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"testb") == f_equal){
            OpcNode = Asm_Testb(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"sete") == f_equal){
            OpcNode = Asm_Sete(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"setne") == f_equal){
            OpcNode = Asm_Setne(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"setg") == f_equal){
            OpcNode = Asm_Setg(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"ja") == f_equal){
            OpcNode = Asm_Ja(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"jg") == f_equal){
            OpcNode = Asm_Jg(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"jge") == f_equal){
            OpcNode = Asm_Jge(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"jl") == f_equal){
            OpcNode = Asm_Jl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"jle") == f_equal){
            OpcNode = Asm_Jle(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"je") == f_equal){
            OpcNode = Asm_Je(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"jne") == f_equal){
            OpcNode = Asm_Jne(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"leal") == f_equal){
            OpcNode = Asm_Leal(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"leave") == f_equal){
            OpcNode = Asm_Leave(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"nop") == f_equal){
            OpcNode = Asm_Nop(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"sarl") == f_equal){
            OpcNode = Asm_Sarl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"sall") == f_equal){
            OpcNode = Asm_Sall(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"andl") == f_equal){
            OpcNode = Asm_Andl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"xorl") == f_equal){
            OpcNode = Asm_Xorl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"jns") == f_equal){
            OpcNode = Asm_Jns(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"notl") == f_equal){
            OpcNode = Asm_Notl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else if(f_strcmp(LineKey,"shrl") == f_equal){
            OpcNode = Asm_Shrl(OpcNode,belfunc,beljump,LineStr);
            beljump = __bel;
        }
        else
            printf("Asm %d line:%s\n",linenumber,LineStr);

        linenumber++;
    }
}
